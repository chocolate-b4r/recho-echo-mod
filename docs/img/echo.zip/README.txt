Ready to drag and drop. No renaming needed.

  Echo Mini\HIFIEC90.IMG                          newest Mini build (v40, left/right Now Playing)
  Echo\RECHOECH.IMG                               newest Echo build (stage 44)
  Echo Mini - backup (classic layout)\HIFIEC90.IMG   Mini v32: the layout before the left/right split

Install: copy the file to the top level of that player's drive, eject, unplug, restart.
The player installs it and deletes the file. Never put one player's file on the other.
This folder is refreshed with every new build. SHA-256 sums: SHA256SUMS.txt

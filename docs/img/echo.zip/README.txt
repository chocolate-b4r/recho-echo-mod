Ready to drag and drop. No renaming needed. The names are FiiO's own update names, so the same
file installs whether the player runs FiiO's firmware or this mod.

  Echo Mini\HIFIEC90.IMG    newest Mini build (v52)
  Echo\ECHOV472.IMG         newest Echo build (stage 61)

Install: copy the file to the top level of that player's drive, eject, unplug, restart.
The player installs it and deletes the file. Never put one player's file on the other.
From Podium (Echo): copy FiiO's ECHOV200.IMG first (Podium installs FiiO), then ECHOV472.IMG.
This folder is refreshed with every new build. SHA-256 sums: SHA256SUMS.txt

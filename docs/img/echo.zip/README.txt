Ready to drag and drop. No renaming needed.

  Echo Mini\HIFIEC90.IMG                          newest Mini build (v52)
  Echo\RECHOECH.IMG                               newest Echo build (stage 60)

Install: copy the file to the top level of that player's drive, eject, unplug, restart.
The player installs it and deletes the file. Never put one player's file on the other.
This folder is refreshed with every new build. SHA-256 sums: SHA256SUMS.txt
